﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MENUSQL.Models;
using System.Data;
using System.Data.SqlClient;

namespace MENUSQL.Datos
{
    public class Menu
    {
        private BDconexion conexion = new BDconexion();

        public List<LoginModels> datoslogin()
        {
          
            SqlDataReader leer;
            DataTable tabla = new DataTable();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion.AbrirConexion();
            comando.CommandText = "segurityConsLogin";
                comando.CommandType = CommandType.StoredProcedure;
                leer = comando.ExecuteReader();
                tabla.Load(leer);
                conexion.CerrarConexion();

                List<LoginModels> loginList = new List<LoginModels>();  
                for (int i = 0; i < tabla.Rows.Count; i++)  
                {  
                    LoginModels login = new LoginModels();  
                    login.UserId = Convert .ToInt32(tabla.Rows[i]["sglid"]);  
                    login.UserName = tabla.Rows[i]["sglusername"].ToString();  
                    login.Password = tabla.Rows[i]["sglpassword"].ToString();  
                    login.UserRoleId = Convert .ToInt32 (tabla.Rows[i]["sglroleid"].ToString());
                    login.RoleName = tabla.Rows[i]["sgrroles"].ToString();  
                    loginList.Add(login);  
                }  

                return loginList;

            
 
        }

        public List<MenuModels> datosMenus(int? idrole)
        {
          
            SqlDataReader leer;
            DataTable tabla = new DataTable();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion.AbrirConexion();
            comando.CommandText = "segurityConsSubmenus";
                comando.CommandType = CommandType.StoredProcedure;
                leer = comando.ExecuteReader();
                tabla.Load(leer);
                conexion.CerrarConexion();

                List<MenuModels> menuList = new List<MenuModels>();  
                for (int i = 0; i < tabla.Rows.Count; i++)  
                {  
                    MenuModels menu = new MenuModels();  
                    menu.MainMenuId = Convert .ToInt32(tabla.Rows[i]["sgmid"]);  
                    menu.MainMenuName = tabla.Rows[i]["sgmmainmenu"].ToString();  
                    menu.SubMenuId = Convert .ToInt32(tabla.Rows[i]["sgsid"].ToString());  
                    menu.ControllerName = tabla.Rows[i]["sgscontroller"].ToString();
                    menu.ActionName = tabla.Rows[i]["sgsaction"].ToString();  
                    menu.RoleId = Convert .ToInt32(tabla.Rows[i]["sgsroleid"].ToString());  
                    menu.RoleName = tabla.Rows[i]["sgrroles"].ToString();  
                    menuList.Add(menu);  
                }

                return menuList;

 
        }


        

    }
}