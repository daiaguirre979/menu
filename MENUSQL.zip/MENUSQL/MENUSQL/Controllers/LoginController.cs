﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MENUSQL.Models;
using System.Web.Security;
using MENUSQL.Datos;

namespace MENUSQL.Controllers
{
    public class LoginController : Controller
    {
        //
        // GET: /Login/

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(LoginModels _login)
        {
            if (ModelState.IsValid) //validating the user inputs
            {
                bool isExist = false;
               
                    List<LoginModels> login = new List<LoginModels>();
                    MENUSQL.Datos.Menu _mn = new Menu();
                    login=_mn.datoslogin();

                    foreach(var usu in login)
                    {
                        if(usu.UserName.Trim().ToLower()== _login.UserName.Trim().ToLower())
                        {
                            isExist = true;
                            LoginModels _loginCredentials= new LoginModels();
                           _loginCredentials.UserName = usu.UserName;
                           _loginCredentials.RoleName = usu.RoleName;
                           _loginCredentials.UserRoleId = usu.UserRoleId;
                           _loginCredentials.UserId = usu.UserId;
                           
                            List<MenuModels> smenus = new List<MenuModels>();
                            smenus=_mn.datosMenus(_loginCredentials.UserRoleId);

                            FormsAuthentication.SetAuthCookie(_loginCredentials.UserName, false); // set the formauthentication cookie
                            Session["LoginCredentials"] = _loginCredentials; // Bind the _logincredentials details to "LoginCredentials" session
                            Session["MenuMaster"] = smenus; //Bind the _menus list to MenuMaster session
                            Session["UserName"] = _loginCredentials.UserName;
                            return RedirectToAction("Index", "Home");
                        }
                     
                }
                if(isExist==false)
                {
                    ViewBag.ErrorMsg = "Please enter the valid credentials!...";
                      return View();
                }

                        
             }
            return View();
      
        }

        public ActionResult LogOff()
        {
            FormsAuthentication.SignOut();
            Session.Abandon();
            Session.Clear();
            Session.RemoveAll();
            return RedirectToAction("Login", "Login");
        }
    }
}
