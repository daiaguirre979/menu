﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Threading;
using System.Web.Mvc;
using WebMatrix.WebData;
using MENUSQL.Models;
using System.Web.Security;


namespace MENUSQL.Helpers
{
    public class CustomProviderProvider : SimpleMembershipProvider
    {
        public override MembershipUser GetUser(string username, bool userIsOnline)
        {
            return base.GetUser(username, userIsOnline);
        }

        public override bool ValidateUser(string username, string password)
        {
            return true; // base.ValidateUser(username, password);
        }
    }
}